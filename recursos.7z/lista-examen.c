#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct miItem {
    int codigo;
    char nombre[20];
    int prioridad; //Del 1 al 5
    int estado; //0 o 1. 0 por defecto
    struct miItem *siguiente;
};
struct miLista
{
    struct miItem *primerItem;
};
int main(void)
{
    struct miLista lista;    
    lista.primerItem = NULL;

    struct miItem *itemNuevo; 
    struct miItem *itemAux, *itemBorrar;     
    int opcion = -1;

    int contador = 0;

    char nombreAux[20];
    int codigoAux;

    do
    {
        printf("Introduzca una opcion\n");
        printf("1. Insertar tarea e imprimir\n");
        printf("2. Listar tareas por programador\n");
        printf("3. Finalizar la tarea e imprimir\n");
        printf("4. Eliminar tareas e imprimir\n");
        printf("5. Salir\n");
        fflush(stdin);
        scanf("%d", &opcion);
        fflush(stdin);
        int encontrado = 0;
        switch (opcion)
        {
        case 1:
            //1. Insertar tarea e imprimir
            itemNuevo = (struct miItem *)malloc(sizeof(struct miItem));
            
            printf("Introduce el nombre del programador:\n");
            scanf("%s",&itemNuevo->nombre);
            fflush(stdin);
            printf("Introduce la prioridad:\n");
            scanf("%i",&itemNuevo->prioridad);
            itemNuevo->siguiente= NULL;    

            itemNuevo->estado = 0;
            if (itemNuevo->prioridad <1 || itemNuevo->prioridad >5)
            {
                printf("La prioridad debe estar entre el 1 y el 5");
                
            }else
            {
                if (lista.primerItem ==NULL)
                {
                    lista.primerItem = itemNuevo;  
                    contador++;
                    lista.primerItem->codigo=contador;

                    itemAux = lista.primerItem;
                    while (itemAux != NULL)
                    {
                        printf("Codigo: %i,  Nombre: %s,  Prioridad: %i , Estado: %i\n", itemAux->codigo, itemAux->nombre, itemAux->prioridad, itemAux->estado);
                        itemAux = itemAux->siguiente;
                    } 

                }else
                {
                    itemAux = lista.primerItem;
                    while (itemAux->siguiente != NULL)
                    {
                        itemAux = itemAux->siguiente;
                    } 
                    itemAux->siguiente = itemNuevo;
                    itemNuevo->codigo = contador;
                    contador++;
                    

                    itemAux = lista.primerItem;
                    while (itemAux != NULL)
                    {
                        printf("Codigo: %i,  Nombre: %s,  Prioridad: %i , Estado: %i\n", itemAux->codigo, itemAux->nombre, itemAux->prioridad, itemAux->estado);
                        itemAux = itemAux->siguiente;
                    } 
                    
                }   
            }



            break;
        case 2:
            //2. Listar tareas por programador
            printf("Introduce un programador:\n");
            scanf("%s", &nombreAux);
            itemAux = lista.primerItem;
            while (itemAux != NULL)
            {
                if (strcmp(nombreAux, itemAux->nombre)== 0)
                {
                    printf("Codigo: %i,  Nombre: %s,  Prioridad: %i , Estado: %i\n", itemAux->codigo, itemAux->nombre, itemAux->prioridad, itemAux->estado);
                    
                }
                itemAux = itemAux->siguiente;
                
            } 

            break;
        case 3:
            //3. Finalizar la tarea e imprimir
            printf("Introduce un codigo:\n");
            scanf("%i", &codigoAux);

            itemAux = lista.primerItem;
            while (itemAux != NULL)
            {
                if (codigoAux == itemAux->codigo)
                {
                    itemAux->estado = 1;
                }
                itemAux = itemAux->siguiente;
            }
            itemAux = lista.primerItem;
            while (itemAux != NULL)
            {
                printf("Codigo: %i,  Nombre: %s,  Prioridad: %i , Estado: %i\n", itemAux->codigo, itemAux->nombre, itemAux->prioridad, itemAux->estado);
                itemAux = itemAux->siguiente;
            } 
            
            
            break;
        case 4:
            //4. Eliminar tareas e imprimir

            itemAux = lista.primerItem;
            while (itemAux != NULL)
            {
                if (itemAux->estado)
                {
                    itemBorrar = itemAux->siguiente;
                    itemAux->siguiente = itemAux->siguiente->siguiente;
                }
                itemAux = itemAux->siguiente;
            }
            
            itemAux = lista.primerItem;
            while (itemAux != NULL)
            {
                printf("Codigo: %i,  Nombre: %s,  Prioridad: %i , Estado: %i\n", itemAux->codigo, itemAux->nombre, itemAux->prioridad, itemAux->estado);
                itemAux = itemAux->siguiente;
            } 

            break;

        case 5:
            printf("Hasta luego Lucas\n");
            break;
        default:
            printf("Opci?n no v?lida\n");
            break;
        }
    } while (opcion != 5);
    printf("Fin del programa");
    return 0;
}