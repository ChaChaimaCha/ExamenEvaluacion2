﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Producto
    {
        private string nombreprod;
        private float precio;

        public Producto(string nombre, float precio)
        {
            this.nombreprod = nombre;
            if (precio < 0)
            {
                this.precio = 10;
            }
            else
            {
                this.precio = precio;
            }

           
        } 
        public float Precio { get => precio;}

        public override bool Equals(object obj)//metodo equals sobreescrito para comparar dos objetos
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))//comprueba que ese objeto es del tipo  y no otro
            {
                return false;
            }
            else
            {
                Producto prod = (Producto)obj; //casting del obj 
                return true; //devuelvo la comparacion de cada parte de los contactos
            }
        }

        public override string ToString()
        {
            StringBuilder imprimir = new StringBuilder();

            imprimir.Append("Nombre del producto: "+ nombreprod+" ,Precio: "+precio);

            return imprimir.ToString();
        }

      
    }
}
