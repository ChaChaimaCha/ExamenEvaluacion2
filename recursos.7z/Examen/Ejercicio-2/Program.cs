﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        { 
            Producto producto1 = new Producto("Libreta", -5f);  //Observa que el precio es menor que 0
            Console.WriteLine(producto1);
            Producto producto2 = new Producto("Bolígrafo", 1f);
            Console.WriteLine(producto2);
            Producto producto3 = new Producto("Pulsera", 9.9f);
            Console.WriteLine(producto3);
            Producto producto4 = new Producto("Gafas de sol", 100.5f);
            Console.WriteLine(producto4);
            Producto producto5 = new Producto("Portátil", 1200f);
            Console.WriteLine(producto5);

            Carrito carrito1 = new Carrito();
            if (carrito1.addProducto(producto1, 1))
            {
                Console.WriteLine("Producto añadido");
            }
            else
            {
                Console.WriteLine("Producto no añadido");
            }

            if (carrito1.addProducto(producto2, 1))
            {
                Console.WriteLine("Producto añadido");
            }
            else
            {
                Console.WriteLine("Producto no añadido");
            }

            if (carrito1.addProducto(producto3, 1))
            {
                Console.WriteLine("Producto añadido");
            }
            else
            {
                Console.WriteLine("Producto no añadido");
            }

            if (carrito1.addProducto(producto4, 1))
            {
                Console.WriteLine("Producto añadido");
            }
            else
            {
                Console.WriteLine("Producto no añadido");
            }
            Console.WriteLine("Imprimo el carrito");
            Console.WriteLine(carrito1);

            //Este producto ya existe en el carrito, debe incrementar las unidades a 10: 9 + 1
            if (carrito1.addProducto(producto1, 9))
            {
                Console.WriteLine("Producto añadido");
            }
            else
            {
                Console.WriteLine("Producto no añadido");
            }

            Console.WriteLine("Imprimo el carrito");
            Console.WriteLine(carrito1);

            Console.WriteLine("Creo otro carrito");

            Carrito carrito2 = new Carrito(); //Se creará con el nombre C-2

            if (carrito2.addProducto(producto5, 1))
            {
                Console.WriteLine("Producto añadido");
            }
            else
            {
                Console.WriteLine("Producto no añadido");
            }

            if (carrito2.addProducto(producto5, 5)) //Este producto ya existe suma 5  + 1
            {
                Console.WriteLine("Producto añadido");
            }

            Console.WriteLine("Imprimo el carrito");
            Console.WriteLine(carrito2);
        }
    }
}
