﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Linea
    {
        private Producto producto;
        private int cantidad;
         
        public Linea(Producto producto, int cantidad)
        {
            this.producto = producto;
            this.Cantidad = cantidad;
        }
        public int Cantidad { get => cantidad; set => cantidad = value; }
        internal Producto Producto { get => producto; }

        public override string ToString()
        {
            StringBuilder imprimir = new StringBuilder();

            imprimir.AppendLine(" Nombre del producto: " + producto +  " Cantidad: "+cantidad); 

            return imprimir.ToString();
        }
        
    
    
    
    
    
    }
}
