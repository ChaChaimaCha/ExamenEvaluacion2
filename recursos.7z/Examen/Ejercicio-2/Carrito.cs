﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Carrito
    {
        private string nomcarrito;
        private Linea[] linea;
        private static int contador = 0;
         
        public Carrito()
        {
            linea = new Linea[3];
            
            nomcarrito = "C-";
            contador++;
        }

        public int productosCarrito()//veo las lineas que tengo
        {
            int numlineas = 0;
            for (int i = 0; i < linea.Length; i++)
            {
                if (linea[i] != null)
                {
                    numlineas++;
                }
            }

            return numlineas;
        }

        public bool addProducto(Producto productoU, int cantidadU) //añado producto
        {

            for (int i = 0; i < linea.Length; i++)
            {
                if (linea[i] != null)
                {
                    
                    if (linea[i].Equals(productoU))
                    {
                        linea[i].Cantidad += cantidadU;
                        return false;
                    }

                }
            }
            Linea lineaU = new Linea(productoU, cantidadU);
            for (int i = 0; i < linea.Length; i++)
            {
                if (linea[i] == null)//si esta vacio
                {
                    linea[i] = lineaU;
                    return true;
                }


            }

            return false;
        }

        public float getTotalPrecioCarrito()
        {
            float total = 0f;
            for (int i = 0; i < linea.Length; i++)
            {
                if (linea[i] != null)
                {
                    total +=(linea[i].Cantidad * linea[i].Producto.Precio)  ;

                }
      
            }
            return total;
        }

        public override string ToString()
        {
            StringBuilder imprimir = new StringBuilder();

            imprimir.AppendLine("CARRITO DE LA COMPRA: "+nomcarrito+contador);

            for (int i = 0; i < linea.Length; i++)
            {
                if (linea[i] != null)//en caso de que la posicion no sea null se imprime
                {
                    imprimir.Append(linea[i].ToString());
                }
            }
            imprimir.AppendLine("TOTAL: "+ getTotalPrecioCarrito());


            return imprimir.ToString();
        }

    }
}
