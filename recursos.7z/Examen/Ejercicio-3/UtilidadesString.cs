﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    class UtilidadesString
    {

        public static char getPalabraAleatoria( int longitud = 10)
        {
            Random palabra = new Random();
            for (int i = 0; i < longitud; i++)
            {
                
                char letra = palabra 
                
            }
            return char.Parse(Console.Write(palabra.Next(65, 91)));
        }
    }
}
