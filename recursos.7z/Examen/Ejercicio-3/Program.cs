﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("getPalabraAleatoria() --> " + UtilidadesString.getPalabraAleatoria()); //Palabra aleatoria de longitud 10
            //Console.WriteLine("getPalabraAleatoria(5) --> " + UtilidadesString.getPalabraAleatoria(5)); //Palabra aleatoria de longitud 5
           // Console.WriteLine("UtilidadesString.getSumaNumeros('Hace 12 días que en clase tuve 23 estudiantes.') -->" + UtilidadesString.getSumaNumeros("Hace 12 días que en clase tuve 23 estudiantes."));



        }
    }
}
